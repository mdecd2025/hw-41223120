from controller import Robot, Keyboard
import time  # 為了賦歸計時

# === 常數定義 ===
TIME_STEP = 32
MAX_VELOCITY = 10.0
ANGLE_STEP = 40 * 3.14159 / 180  # 40 度轉為弧度
POSITION_M = ANGLE_STEP          # 升起位置 (+40°)
POSITION_K = 0.0                 # 回復位置 (0°)

# === 初始化 Webots 裝置 ===
robot = Robot()
timestep = int(robot.getBasicTimeStep())

keyboard = Keyboard()
keyboard.enable(timestep)

# === 嘗試取得馬達與感測器 ===
try:
    motor = robot.getDevice('motor1')
    sensor = robot.getDevice('motor1_sensor')
    sensor.enable(timestep)
    mechanism_enabled = True
except Exception:
    mechanism_enabled = False

# === 嘗試取得輪子裝置 ===
try:
    wheels = [robot.getDevice(f"wheel{i+1}") for i in range(4)]
    for wheel in wheels:
        wheel.setPosition(float('inf'))  # 啟用速度模式
        wheel.setVelocity(0)             # 初始速度為 0
    platform_enabled = True
except Exception:
    platform_enabled = False

# === 初始提示 ===
print("使用方向鍵控制平台移動：↑ 前進，↓ 後退，← 左轉，→ 右轉")
print("按 M 可升起機構，將於 1 秒後自動回復")
print("按 Q 離開程式")

# === 馬達控制狀態 ===
key_pressed = {'m': False}
mechanism_raised = False       # 是否目前為升起狀態
raise_start_time = None        # 升起開始時間（記錄用）

# === 主控制迴圈 ===
while robot.step(timestep) != -1:
    key = keyboard.getKey()
    current_time = time.time()

    # === 四輪平台移動控制 ===
    if platform_enabled:
        if key == Keyboard.UP:
            for wheel in wheels:
                wheel.setVelocity(MAX_VELOCITY)
        elif key == Keyboard.DOWN:
            for wheel in wheels:
                wheel.setVelocity(-MAX_VELOCITY)
        elif key == Keyboard.LEFT:
            wheels[0].setVelocity(MAX_VELOCITY)
            wheels[1].setVelocity(-MAX_VELOCITY)
            wheels[2].setVelocity(MAX_VELOCITY)
            wheels[3].setVelocity(-MAX_VELOCITY)
        elif key == Keyboard.RIGHT:
            wheels[0].setVelocity(-MAX_VELOCITY)
            wheels[1].setVelocity(MAX_VELOCITY)
            wheels[2].setVelocity(-MAX_VELOCITY)
            wheels[3].setVelocity(MAX_VELOCITY)
        elif key == ord('Q') or key == ord('q'):
            print("離開程式...")
            break
        else:
            for wheel in wheels:
                wheel.setVelocity(0)

    # === 機構升起＋自動賦歸控制 ===
    if mechanism_enabled:
        motor_position = sensor.getValue()

        # 按下 M 鍵時觸發升起（且尚未升起）
        if key == ord('M') or key == ord('m'):
            if not key_pressed['m'] and not mechanism_raised:
                motor.setPosition(POSITION_M)
                print("投球")
                mechanism_raised = True
                raise_start_time = current_time
            key_pressed['m'] = True
        else:
            key_pressed['m'] = False

        # 已升起 → 檢查是否超過1秒 → 回復
        if mechanism_raised and raise_start_time is not None:
            if current_time - raise_start_time >= 1.0:
                motor.setPosition(POSITION_K)
                print("自動回復")
                mechanism_raised = False
                raise_start_time = None
